public class VelocException extends Exception
{
	public VelocException()
	{
		System.out.println("\n\t🔴 A velocidade máxima está fora "
			+ "dos limites brasileiros");
	}
}
